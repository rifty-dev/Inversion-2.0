package com.wispsmp.divisionrod;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * All rod behaviour. Feedback is sound and particles only - nothing is ever
 * written to chat or the action bar.
 */
public final class RodListener implements Listener {

    /**
     * Right-click fires twice on some client/server combos; this swallows the
     * echo so one click cannot both lock and swap. It is not a use cooldown -
     * consecutive real clicks are always accepted.
     */
    private static final long CLICK_DEBOUNCE_MILLIS = 150L;

    private final DivisionRodPlugin plugin;
    private final Map<UUID, Long> lastClick = new HashMap<>();

    public RodListener(DivisionRodPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------
    // Vanilla behaviour removal
    // ------------------------------------------------------------------

    /** Belt and braces: never let a bobber exist for one of our rods. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        Player player = event.getPlayer();
        if (plugin.rods().fromItem(player.getInventory().getItemInMainHand()) != null
                || plugin.rods().fromItem(player.getInventory().getItemInOffHand()) != null) {
            event.setCancelled(true);
            if (event.getHook() != null) {
                event.getHook().remove();
            }
        }
    }

    // ------------------------------------------------------------------
    // Rod usage
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        RodSettings rod = plugin.rods().fromItem(item);
        if (rod == null) {
            return;
        }

        // Kill the vanilla cast entirely.
        event.setCancelled(true);
        event.setUseItemInHand(Event.Result.DENY);
        event.setUseInteractedBlock(Event.Result.DENY);

        handleClick(event.getPlayer(), rod);
    }

    /**
     * Right-clicking an entity inside interaction range fires this instead of
     * PlayerInteractEvent, so the rod has to be handled here too.
     */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = false)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Player player = event.getPlayer();
        RodSettings rod = plugin.rods().fromItem(player.getInventory().getItemInMainHand());
        if (rod == null) {
            return;
        }
        event.setCancelled(true);
        handleClick(player, rod);
    }

    private void handleClick(Player player, RodSettings rod) {
        long now = System.currentTimeMillis();
        Long last = lastClick.get(player.getUniqueId());
        if (last != null && now - last < CLICK_DEBOUNCE_MILLIS) {
            return;
        }
        lastClick.put(player.getUniqueId(), now);

        LinkManager.Link link = plugin.links().get(player.getUniqueId());
        if (link != null && link.rodId().equals(rod.id())) {
            attemptSwap(player, rod, link);
        } else {
            attemptLock(player, rod);
        }
    }

    // ------------------------------------------------------------------
    // Step 1 - lock in
    // ------------------------------------------------------------------

    private void attemptLock(Player player, RodSettings rod) {
        Entity target = raycast(player, rod.range());
        if (target == null) {
            plugin.links().clear(player.getUniqueId());
            plugin.rods().setVisualLocked(player, rod, false);
            return;
        }

        plugin.links().link(player.getUniqueId(), target.getUniqueId(), rod.id());
        plugin.rods().setVisualLocked(player, rod, true);

        playSound(player.getLocation(), rod.lockSound(), rod);
        playSound(target.getLocation(), rod.lockSound(), rod);
        if (rod.particles()) {
            spawnLinkParticles(player.getLocation());
            spawnLinkParticles(target.getLocation());
        }
    }

    /**
     * Precise crosshair raycast. Blocks cut the ray short so you cannot lock on
     * through a wall (configurable).
     */
    private Entity raycast(Player player, double range) {
        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection();

        double distance = range;
        if (plugin.requireLineOfSight()) {
            RayTraceResult blockHit = world.rayTraceBlocks(eye, direction, range, FluidCollisionMode.NEVER, true);
            if (blockHit != null && blockHit.getHitPosition() != null) {
                distance = Math.min(range, blockHit.getHitPosition().distance(eye.toVector()));
            }
        }

        RayTraceResult hit = world.rayTraceEntities(eye, direction, distance, 0.35D, entity -> {
            if (entity.getUniqueId().equals(player.getUniqueId()) || entity.isDead()) {
                return false;
            }
            if (entity instanceof Player other) {
                return other.getGameMode() != GameMode.SPECTATOR;
            }
            return true;
        });
        return hit == null ? null : hit.getHitEntity();
    }

    // ------------------------------------------------------------------
    // Step 2 - swap
    // ------------------------------------------------------------------

    private void attemptSwap(Player player, RodSettings rod, LinkManager.Link link) {
        Entity target = Bukkit.getEntity(link.target());

        if (target == null || target.isDead() || !target.isValid()) {
            breakLink(player, rod);
            return;
        }
        if (!target.getWorld().equals(player.getWorld())) {
            if (!plugin.allowCrossWorld()) {
                breakLink(player, rod);
                return;
            }
        } else if (target.getLocation().distanceSquared(player.getLocation()) > rod.rangeSquared()) {
            breakLink(player, rod);
            return;
        }

        swap(player, target, rod);
        breakLink(player, rod);
    }

    private void breakLink(Player player, RodSettings rod) {
        plugin.links().clear(player.getUniqueId());
        plugin.rods().setVisualLocked(player, rod, false);
    }

    private void swap(Player player, Entity target, RodSettings rod) {
        Location playerLoc = player.getLocation().clone();
        Location targetLoc = target.getLocation().clone();

        Vector playerVelocity = player.getVelocity().clone();
        Vector targetVelocity = target.getVelocity().clone();

        float playerFall = player.getFallDistance();
        float targetFall = target.getFallDistance();

        // Riding anything would cancel the teleport.
        player.leaveVehicle();
        target.leaveVehicle();
        player.eject();
        target.eject();

        // Coordinates AND camera angles (yaw + pitch) come along for the ride.
        target.teleport(playerLoc);
        player.teleport(targetLoc);

        if (plugin.preserveVelocity()) {
            player.setVelocity(targetVelocity);
            target.setVelocity(playerVelocity);
        }
        if (plugin.resetFallDistance()) {
            player.setFallDistance(0.0F);
            target.setFallDistance(0.0F);
        } else {
            player.setFallDistance(targetFall);
            target.setFallDistance(playerFall);
        }

        // Nausea lands on the entity that got swapped, never on the rod user.
        if (rod.nauseaTicks() > 0 && target instanceof LivingEntity living) {
            living.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, rod.nauseaTicks(), 0, false, true, true));
        }

        playSound(playerLoc, rod.swapSound(), rod);
        playSound(targetLoc, rod.swapSound(), rod);
        if (rod.particles()) {
            spawnSwapParticles(playerLoc);
            spawnSwapParticles(targetLoc);
        }
    }

    // ------------------------------------------------------------------
    // Cleanup
    // ------------------------------------------------------------------

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        plugin.links().clear(id);
        plugin.links().clearTargeting(id);
        plugin.rods().clearVisuals(player);
        lastClick.remove(id);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID id = player.getUniqueId();
        plugin.links().clear(id);
        plugin.links().clearTargeting(id);
        plugin.rods().clearVisuals(player);
    }

    // ------------------------------------------------------------------
    // Feedback
    // ------------------------------------------------------------------

    private void playSound(Location location, String sound, RodSettings rod) {
        if (sound == null || sound.isEmpty() || location.getWorld() == null) {
            return;
        }
        location.getWorld().playSound(location, sound, SoundCategory.PLAYERS, rod.soundVolume(), rod.soundPitch());
    }

    private void spawnLinkParticles(Location location) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        Location center = location.clone().add(0.0D, 1.0D, 0.0D);
        world.spawnParticle(Particle.SCULK_SOUL, center, 25, 0.35D, 0.6D, 0.35D, 0.02D, null);
        world.spawnParticle(Particle.SHRIEK, center, 1, 0.0D, 0.0D, 0.0D, 0.0D, Integer.valueOf(0));
        world.spawnParticle(Particle.DUST, center, 30, 0.4D, 0.7D, 0.4D, 0.0D,
                new Particle.DustOptions(Color.fromRGB(255, 0, 40), 1.1F));
    }

    private void spawnSwapParticles(Location location) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        Location center = location.clone().add(0.0D, 1.0D, 0.0D);
        world.spawnParticle(Particle.SCULK_CHARGE_POP, center, 40, 0.5D, 0.8D, 0.5D, 0.05D, null);
        world.spawnParticle(Particle.SCULK_SOUL, center, 20, 0.4D, 0.7D, 0.4D, 0.03D, null);
        world.spawnParticle(Particle.DUST, center, 45, 0.5D, 0.9D, 0.5D, 0.0D,
                new Particle.DustOptions(Color.fromRGB(255, 0, 40), 1.3F));
    }
}
