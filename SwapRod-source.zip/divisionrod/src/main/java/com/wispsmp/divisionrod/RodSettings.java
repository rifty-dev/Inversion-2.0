package com.wispsmp.divisionrod;

/**
 * Immutable configuration for one rod variant (division / inversion).
 */
public final class RodSettings {

    private final String id;
    private final String displayName;
    private final double range;
    private final String itemModel;
    private final String lockedItemModel;
    private final String lockSound;
    private final String swapSound;
    private final float soundVolume;
    private final float soundPitch;
    private final boolean particles;
    private final int nauseaTicks;

    public RodSettings(String id,
                       String displayName,
                       double range,
                       String itemModel,
                       String lockedItemModel,
                       String lockSound,
                       String swapSound,
                       float soundVolume,
                       float soundPitch,
                       boolean particles,
                       int nauseaTicks) {
        this.id = id;
        this.displayName = displayName;
        this.range = range;
        this.itemModel = itemModel;
        this.lockedItemModel = lockedItemModel;
        this.lockSound = lockSound;
        this.swapSound = swapSound;
        this.soundVolume = soundVolume;
        this.soundPitch = soundPitch;
        this.particles = particles;
        this.nauseaTicks = nauseaTicks;
    }

    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public double range() {
        return range;
    }

    public double rangeSquared() {
        return range * range;
    }

    public String itemModel() {
        return itemModel;
    }

    /** Texture shown while a target is locked in. Empty = no visual change. */
    public String lockedItemModel() {
        return lockedItemModel;
    }

    public boolean hasLockedModel() {
        return lockedItemModel != null && !lockedItemModel.isEmpty();
    }

    public String lockSound() {
        return lockSound;
    }

    public String swapSound() {
        return swapSound;
    }

    public float soundVolume() {
        return soundVolume;
    }

    public float soundPitch() {
        return soundPitch;
    }

    public boolean particles() {
        return particles;
    }

    public int nauseaTicks() {
        return nauseaTicks;
    }
}
