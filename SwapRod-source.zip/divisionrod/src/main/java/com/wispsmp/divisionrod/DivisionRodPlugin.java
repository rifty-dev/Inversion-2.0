package com.wispsmp.divisionrod;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class DivisionRodPlugin extends JavaPlugin {

    private RodRegistry rods;
    private LinkManager links;

    private boolean requireLineOfSight = true;
    private boolean allowCrossWorld = false;
    private boolean preserveVelocity = false;
    private boolean resetFallDistance = false;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.links = new LinkManager();
        this.rods = new RodRegistry(this);
        readSettings();

        getServer().getPluginManager().registerEvents(new RodListener(this), this);

        PluginCommand command = getCommand("swaprod");
        if (command != null) {
            SwapRodCommand executor = new SwapRodCommand(this);
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }
    }

    @Override
    public void onDisable() {
        if (links != null) {
            links.clearAll();
        }
    }

    public void reload() {
        reloadConfig();
        rods.load();
        readSettings();
        links.clearAll();
    }

    private void readSettings() {
        requireLineOfSight = getConfig().getBoolean("settings.require-line-of-sight", true);
        allowCrossWorld = getConfig().getBoolean("settings.allow-cross-world", false);
        preserveVelocity = getConfig().getBoolean("settings.preserve-velocity", false);
        resetFallDistance = getConfig().getBoolean("settings.reset-fall-distance", false);
        links.setTimeoutSeconds(getConfig().getDouble("settings.link-timeout-seconds", 0.0D));
    }

    public RodRegistry rods() {
        return rods;
    }

    public LinkManager links() {
        return links;
    }

    public boolean requireLineOfSight() {
        return requireLineOfSight;
    }

    public boolean allowCrossWorld() {
        return allowCrossWorld;
    }

    public boolean preserveVelocity() {
        return preserveVelocity;
    }

    public boolean resetFallDistance() {
        return resetFallDistance;
    }
}
