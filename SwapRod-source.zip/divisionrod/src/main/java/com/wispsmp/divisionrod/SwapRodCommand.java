package com.wispsmp.divisionrod;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * /swaprod &lt;Division|Inversion&gt; [player]
 * /swaprod reload
 */
public final class SwapRodCommand implements CommandExecutor, TabCompleter {

    private final DivisionRodPlugin plugin;

    public SwapRodCommand(DivisionRodPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Component.text("/" + label + " <" + String.join("|", names()) + "> [player]",
                    NamedTextColor.GRAY));
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("swaprod.reload")) {
                sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                return true;
            }
            plugin.reload();
            sender.sendMessage(Component.text("Config reloaded.", NamedTextColor.GREEN));
            return true;
        }

        if (!sender.hasPermission("swaprod.give")) {
            sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
            return true;
        }

        RodSettings rod = plugin.rods().get(args[0]);
        if (rod == null) {
            sender.sendMessage(Component.text("Unknown rod: " + args[0], NamedTextColor.RED));
            return true;
        }

        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found: " + args[1], NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage(Component.text("Console must name a player.", NamedTextColor.RED));
            return true;
        }

        target.getInventory().addItem(plugin.rods().build(rod));
        sender.sendMessage(Component.text("Gave " + rod.displayName() + " to " + target.getName() + ".",
                NamedTextColor.GREEN));
        return true;
    }

    private List<String> names() {
        List<String> out = new ArrayList<>();
        for (RodSettings rod : plugin.rods().all().values()) {
            out.add(capitalise(rod.id()));
        }
        return out;
    }

    private String capitalise(String id) {
        return id.isEmpty() ? id : Character.toUpperCase(id.charAt(0)) + id.substring(1);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase();
            for (RodSettings rod : plugin.rods().all().values()) {
                if (rod.id().startsWith(prefix)) {
                    out.add(capitalise(rod.id()));
                }
            }
            if ("reload".startsWith(prefix) && sender.hasPermission("swaprod.reload")) {
                out.add("reload");
            }
        } else if (args.length == 2 && plugin.rods().get(args[0]) != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    out.add(player.getName());
                }
            }
        }
        return out;
    }
}
