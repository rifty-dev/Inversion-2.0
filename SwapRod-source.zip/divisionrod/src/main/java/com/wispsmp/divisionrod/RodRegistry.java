package com.wispsmp.divisionrod;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Loads rod variants from config.yml, builds their ItemStacks, identifies them
 * again through the persistent data container and drives the locked/idle texture.
 */
public final class RodRegistry {

    private final DivisionRodPlugin plugin;
    private final NamespacedKey rodKey;
    private final Map<String, RodSettings> rods = new LinkedHashMap<>();

    public RodRegistry(DivisionRodPlugin plugin) {
        this.plugin = plugin;
        this.rodKey = new NamespacedKey(plugin, "rod_type");
        load();
    }

    public void load() {
        rods.clear();
        ConfigurationSection root = plugin.getConfig().getConfigurationSection("rods");
        if (root == null) {
            plugin.getLogger().warning("No 'rods' section in config.yml - no rods loaded.");
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) {
                continue;
            }
            String key = id.toLowerCase();
            rods.put(key, new RodSettings(
                    key,
                    s.getString("display-name", id),
                    s.getDouble("range", 15.0D),
                    s.getString("item-model", ""),
                    s.getString("item-model-locked", ""),
                    s.getString("lock-sound", "minecraft:block.chain.place"),
                    s.getString("swap-sound", "minecraft:block.chain.break"),
                    (float) s.getDouble("sound-volume", 1.0D),
                    (float) s.getDouble("sound-pitch", 1.0D),
                    s.getBoolean("particles", false),
                    Math.max(0, (int) Math.round(s.getDouble("nausea-seconds", 0.0D) * 20.0D))
            ));
        }
        plugin.getLogger().info("Loaded " + rods.size() + " rod variant(s): " + rods.keySet());
    }

    public RodSettings get(String id) {
        return id == null ? null : rods.get(id.toLowerCase());
    }

    public Map<String, RodSettings> all() {
        return rods;
    }

    /**
     * @return the rod settings for this item, or null if it is not one of our rods.
     */
    public RodSettings fromItem(ItemStack item) {
        if (item == null || item.getType() != Material.FISHING_ROD) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        return get(pdc.get(rodKey, PersistentDataType.STRING));
    }

    public ItemStack build(RodSettings settings) {
        ItemStack item = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta meta = item.getItemMeta();

        // White, non-italic name. No lore, no extra flags.
        Component name = Component.text(settings.displayName());
        name = name.color(NamedTextColor.WHITE);
        name = name.decoration(TextDecoration.ITALIC, false);
        meta.displayName(name);

        meta.addEnchant(Enchantment.UNBREAKING, 3, true);

        applyModel(meta, settings, false);
        meta.getPersistentDataContainer().set(rodKey, PersistentDataType.STRING, settings.id());
        item.setItemMeta(meta);
        return item;
    }

    private void applyModel(ItemMeta meta, RodSettings settings, boolean locked) {
        String model = locked && settings.hasLockedModel() ? settings.lockedItemModel() : settings.itemModel();
        if (model == null || model.isEmpty()) {
            meta.setItemModel(null);
            return;
        }
        NamespacedKey modelKey = NamespacedKey.fromString(model);
        if (modelKey == null) {
            plugin.getLogger().warning("Invalid item-model key for rod '" + settings.id() + "': " + model);
            return;
        }
        meta.setItemModel(modelKey);
    }

    /**
     * Repoints every copy of this rod in the player's inventory at the locked or
     * idle texture. Scans the whole inventory rather than the held slot so the
     * texture survives hotbar juggling during a wind charge combo.
     */
    public void setVisualLocked(Player player, RodSettings settings, boolean locked) {
        if (!settings.hasLockedModel()) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack item = inventory.getItem(slot);
            if (fromItem(item) != settings) {
                continue;
            }
            ItemMeta meta = item.getItemMeta();
            applyModel(meta, settings, locked);
            item.setItemMeta(meta);
            inventory.setItem(slot, item);
        }
    }

    /** Resets every rod the player is carrying back to its idle texture. */
    public void clearVisuals(Player player) {
        for (RodSettings settings : rods.values()) {
            setVisualLocked(player, settings, false);
        }
    }
}
