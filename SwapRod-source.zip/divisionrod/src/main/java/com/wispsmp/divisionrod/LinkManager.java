package com.wispsmp.divisionrod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Holds the "chain link" between a player and the entity they locked on to.
 * The link survives hotbar switches, wind charge jumps, inventory edits - it is
 * only cleared on swap, timeout, failure, death or quit.
 */
public final class LinkManager {

    public static final class Link {
        private final UUID target;
        private final String rodId;
        private final long createdAt;

        Link(UUID target, String rodId) {
            this.target = target;
            this.rodId = rodId;
            this.createdAt = System.currentTimeMillis();
        }

        public UUID target() {
            return target;
        }

        public String rodId() {
            return rodId;
        }

        public long createdAt() {
            return createdAt;
        }
    }

    private final Map<UUID, Link> links = new HashMap<>();
    private long timeoutMillis;

    public void setTimeoutSeconds(double seconds) {
        this.timeoutMillis = seconds <= 0 ? 0L : (long) (seconds * 1000.0D);
    }

    public void link(UUID player, UUID target, String rodId) {
        links.put(player, new Link(target, rodId));
    }

    /**
     * @return the active link, or null if there is none or it has expired.
     */
    public Link get(UUID player) {
        Link link = links.get(player);
        if (link == null) {
            return null;
        }
        if (timeoutMillis > 0L && System.currentTimeMillis() - link.createdAt() > timeoutMillis) {
            links.remove(player);
            return null;
        }
        return link;
    }

    public void clear(UUID player) {
        links.remove(player);
    }

    public void clearAll() {
        links.clear();
    }

    /** Drops any link that pointed at this entity (it died / logged out). */
    public void clearTargeting(UUID target) {
        links.values().removeIf(link -> link.target().equals(target));
    }
}
